# DCS-BIOS Arduino Library

This is an Arduino library that makes it easy to write sketches that talk to DCS-BIOS.

For more information and documentation, see the [DCS-BIOS project.](https://github.com/dcs-bios/dcs-bios)

add polling support to new controls (by Blue73 [ED Forum](https://forums.eagle.ru/showthread.php?t=230222) )
