﻿using System;

namespace DcsBiosCOMHandler
{
    public interface ISerialPortListener
    {
        void GetSerialPortData(String serialPortData);
    }
}
