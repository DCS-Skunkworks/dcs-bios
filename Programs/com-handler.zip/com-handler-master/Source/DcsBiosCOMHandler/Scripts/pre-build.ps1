if($args[0] -match "Release"){		
	.\build_version_update.ps1	
}

exit 0