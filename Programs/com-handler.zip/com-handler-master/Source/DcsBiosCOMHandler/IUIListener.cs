﻿namespace DcsBiosCOMHandler
{
    public interface IUIListener
    {
        void ChangesHasBeenMade();
    }
}
